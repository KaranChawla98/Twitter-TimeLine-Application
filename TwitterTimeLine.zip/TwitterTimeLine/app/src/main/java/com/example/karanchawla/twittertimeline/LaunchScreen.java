package com.example.karanchawla.twittertimeline;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class LaunchScreen extends AppCompatActivity {

    public String username = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_launch_screen);
        final EditText et = (EditText)findViewById(R.id.editText);
        Button b = (Button)findViewById(R.id.gobutton);
        final EditText keywords = (EditText)findViewById(R.id.editTextWords);
        final EditText hashtags = (EditText)findViewById(R.id.editTextHash);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(et.getText().toString() == ""){
                    username = "HDWallpaperFree";
                    Intent i = new Intent(view.getContext(), MainActivity.class);
                    Bundle bundle = new Bundle();
                    bundle.putString("username", username);
                    bundle.putString("keywords", keywords.getText().toString());
                    bundle.putString("hash", hashtags.getText().toString());
                    i.putExtras(bundle);
                    startActivity(i);
                }
                else{
                    username = et.getText().toString();
                    Intent i = new Intent(view.getContext(), MainActivity.class);
                    Bundle bundle = new Bundle();
                    bundle.putString("username", username);
                    bundle.putString("keywords", keywords.getText().toString());
                    bundle.putString("hash", hashtags.getText().toString());
                    i.putExtras(bundle);
                    startActivity(i);
                }
            }
        });

    }

}
