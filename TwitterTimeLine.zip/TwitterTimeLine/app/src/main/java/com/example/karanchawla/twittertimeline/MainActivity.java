package com.example.karanchawla.twittertimeline;

import android.app.ListActivity;
import android.os.Bundle;

import com.twitter.sdk.android.core.Twitter;
import com.twitter.sdk.android.tweetui.BasicTimelineFilter;
import com.twitter.sdk.android.tweetui.FilterValues;
import com.twitter.sdk.android.tweetui.SearchTimeline;
import com.twitter.sdk.android.tweetui.TimelineFilter;
import com.twitter.sdk.android.tweetui.TweetTimelineListAdapter;
import com.twitter.sdk.android.tweetui.UserTimeline;

import java.util.Arrays;
import java.util.List;
import java.util.Locale;

public class MainActivity extends ListActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Twitter.initialize(this);
        Bundle bundle = getIntent().getExtras();
        String username = bundle.getString("username");
        String words = bundle.getString("keywords");
        String hash = bundle.getString("hash");
        UserTimeline userTimeline = new UserTimeline.Builder().screenName(username).build();
        final List<String> keywords= Arrays.asList(words.split(","));
        final List<String> hashtags = Arrays.asList(hash.split(","));

        final FilterValues filterValues = new FilterValues(keywords, hashtags, null, null); // or load from JSON, XML, etc
        final TimelineFilter timelineFilter = new BasicTimelineFilter(filterValues, Locale.ENGLISH);
        TweetTimelineListAdapter adapter = new TweetTimelineListAdapter.Builder(this)
                .setTimeline(userTimeline)
                .setTimelineFilter(timelineFilter)
                .build();
        setListAdapter(adapter);




    }
}
